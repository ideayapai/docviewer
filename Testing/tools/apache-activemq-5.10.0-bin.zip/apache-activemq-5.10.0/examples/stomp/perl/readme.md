Prereqs
=======

Install the [Net:STOMP::Client](http://search.cpan.org/dist/Net-STOMP-Client/) 
library.

CPAN users can install it by running:

    cpan Net:STOMP::Client


